/* *****************************************
 * CSCI205 -Software Engineering and Design
 * Fall 2021
 * Instructor: Prof. Brian King
 *
 * Name: Austin Beal
 * Section: 02 - 9:50
 * Date: 11/17/21
 * Time: 10:38 AM
 *
 * Project: csci205_final_project
 * Package: a.b.baseclass
 * Class: TestCode
 *
 * Description:
 *
 * ****************************************
 */

package TestCodeThroughout;

import java.time.LocalDate;

public class TestCode {
    public static void main(String[] args) {/*
        Administrator admin = new Administrator("Austin", 19, LocalDate.now(), "alb049", "password");
        User u = new User("Tim", 19, LocalDate.now());
        User u2 = new User("Jordan", 19, LocalDate.now());
        User u3 = new User("Conrad", 20, LocalDate.now());
        User u4 = new User("Thomas", 22, LocalDate.now());
        admin.addUsear(u);
        admin.addUser(u2);
        admin.addUser(u3);
        admin.addUser(u4);
        admin.seeUsers();
        */



    }

}







