/* *****************************************

 * CSCI205 - Software Engineering and Design

 * Fall 2021

 * Instructor: Prof. Brian King

 *

 * Name: YOUR NAME

 * Section: YOUR SECTION

 * Date: 12/4/21

 * Time: 11:05 PM

 *

 * Project: csci205_final_project

 * Package: main

 * Class: timerThread *

 * Description:

 *

 * ****************************************

 */

package main;

public class timerThread {
}


