/* *****************************************

 * CSCI205 - Software Engineering and Design

 * Fall 2021

 * Instructor: Prof. Brian King

 *

 * Name: Tim Zelikovsy, Austin Beal. Conrad Percowski, Jordan Miller

 * Section: 02- 9:50AM

 * Date: 11/9/21

 * Time: 2:08 AM

 *

 * Project: csci205_final_project

 * Package: main

 * Class: Main *

 * Description:

 *

 * ****************************************

 */

package main;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello CS Industry Success!");
    }
}


