package TestCodeThroughout.productivityGraph;

import javafx.application.Application;
import javafx.stage.Stage;

public class productivityGraph extends Application {

    @Override
    public void start(Stage primaryStage) {
    }

}
